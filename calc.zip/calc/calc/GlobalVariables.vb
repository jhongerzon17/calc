﻿Module GlobalVariables
    Public Operand1 As String = ""
    Public Operand2 As String = ""
    Public Oprtr As String = ""
End Module
